/* ============================================================
 * vk-compliance.js · v0.46.1 · соответствие правилам VK Mini Apps
 * Добавляется ПОВЕРХ игры, ничего не переписывает.
 *
 * 1) Экран загрузки (Правила 3.5.2: спиннер/прогресс при загрузке)
 *    — плашка с иконкой и спиннером, гаснет, когда игра готова.
 * 2) VKWebAppViewHide (Правила 2.2.5: звук не должен играть после
 *    закрытия приложения) + пауза музыки при уходе с вкладки.
 * 3) Ссылка на поддержку и короткая строка о данных (Правила 2.4.1–2.4.2)
 *    в экране «Как играть». Контакт задаётся в SUPPORT ниже.
 * 4) Кнопка «Рассказать друзьям» (VKWebAppShare) — соц. механика,
 *    которую VK рекомендует для публикации в каталоге.
 * ============================================================ */
(function () {
  'use strict';

  /* ── ЗАПОЛНИТЕ: канал поддержки и сообщество ───────────────── */
  var SUPPORT = {
    url: 'https://vk.com/',          /* ← ссылка на сообщество/личную страницу поддержки */
    label: 'Поддержка игры',
    community: ''                    /* ← ID сообщества, если нужен VKWebAppJoinGroup */
  };

  var bridge = window.vkBridge || window.vkConnect || null;
  var isVk = !!(bridge && bridge.send);

  /* ── 1. Экран загрузки ─────────────────────────────────────── */
  var css = document.createElement('style');
  css.textContent = [
    '#boot-splash{position:fixed;inset:0;z-index:9999;display:flex;flex-direction:column;',
    ' align-items:center;justify-content:center;gap:18px;background:radial-gradient(1200px 700px at 50% 30%,#14203c,#05070d);',
    ' color:#e9e4d6;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;transition:opacity .45s ease}',
    '#boot-splash.off{opacity:0;pointer-events:none}',
    '#boot-splash .bs-ico{width:96px;height:96px;border-radius:24px;box-shadow:0 14px 40px rgba(0,0,0,.55),0 0 0 2px rgba(232,197,106,.35)}',
    '#boot-splash .bs-t{font-size:17px;font-weight:700;letter-spacing:.06em;color:#e8c56a}',
    '#boot-splash .bs-s{font-size:13px;color:#93a2c4}',
    '#boot-splash .bs-sp{width:30px;height:30px;border-radius:50%;border:3px solid rgba(232,197,106,.25);',
    ' border-top-color:#e8c56a;animation:bsSpin .9s linear infinite}',
    '@keyframes bsSpin{to{transform:rotate(360deg)}}',
    '#btn-share-game{display:inline-flex;align-items:center;gap:8px}'
  ].join('');
  document.head.appendChild(css);

  var splash = document.createElement('div');
  splash.id = 'boot-splash';
  splash.innerHTML =
    '<img class="bs-ico" src="' + (window.__ICON_URL || 'img/icon_192.png') + '" alt="">' +
    '<div class="bs-sp"></div>' +
    '<div class="bs-t">КАМЕНЬ-НОЖНИЦЫ-БУМ!</div>' +
    '<div class="bs-s">Загружаем игру…</div>';
  window.addEventListener('DOMContentLoaded', function () {
    if (!document.body) return;
    document.body.appendChild(splash);
  });

  function hideSplash() {
    if (!splash || splash.classList.contains('off')) return;
    splash.classList.add('off');
    setTimeout(function () { if (splash.parentNode) splash.parentNode.removeChild(splash); }, 600);
  }
  /* прячем, когда отрисовался первый кадр и мост инициализирован */
  window.addEventListener('load', function () {
    var tries = 0;
    var t = setInterval(function () {
      tries++;
      var ready = false;
      try {
        ready = window.game && window.game.phase && document.getElementById('scr-start');
      } catch (e) {}
      if (ready || tries > 60) { clearInterval(t); setTimeout(hideSplash, 350); }
    }, 100);
  });
  /* страховка: не держим плашку дольше 8 секунд */
  setTimeout(hideSplash, 8000);

  /* ── 2. VKWebAppViewHide: гасим звук при закрытии ──────────── */
  function muteAll() {
    try {
      if (window.Snd) { window.Snd.on = false; if (window.Snd.ctx && window.Snd.ctx.state === 'running') window.Snd.ctx.suspend(); }
      if (window.Music && window.Music.stop) window.Music.stop();
    } catch (e) {}
    /* не меняем пользовательскую настройку: возвращаем после показа */
  }
  var wasOn = null;
  function pauseSound() {
    try { wasOn = window.Snd ? !!window.Snd.on : null; } catch (e) { wasOn = null; }
    muteAll();
  }
  function resumeSound() {
    try {
      if (wasOn && window.Snd) {
        window.Snd.on = true;
        if (window.Snd.ctx && window.Snd.ctx.state === 'suspended') window.Snd.ctx.resume();
      }
    } catch (e) {}
  }
  if (isVk) {
    try {
      bridge.subscribe(function (e) {
        if (!e || !e.detail) return;
        var type = e.detail.type;
        if (type === 'VKWebAppViewHide') pauseSound();
        if (type === 'VKWebAppViewRestore') resumeSound();
      });
    } catch (e) {}
  }
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) pauseSound(); else resumeSound();
  });

  /* ── 3. Поддержка + строка о данных в «Как играть» ─────────── */
  function addSupportBlock() {
    var host = document.getElementById('help-blocks');
    if (!host || document.getElementById('vk-support-block')) return;
    var box = document.createElement('div');
    box.id = 'vk-support-block';
    box.style.cssText = 'margin:10px 0 4px;padding:12px 14px;border-radius:14px;border:1px solid rgba(232,197,106,.30);' +
      'background:rgba(20,28,52,.6);font-size:14px;line-height:1.5;color:#c6d2ee';
    box.innerHTML =
      '<b style="color:#e8c56a">Поддержка</b><br>' +
      'Вопросы, ошибки, предложения: <a href="' + SUPPORT.url + '" target="_blank" rel="noopener" ' +
      'style="color:#3ddc84;text-decoration:none;border-bottom:1px dashed rgba(61,220,132,.5)">' +
      SUPPORT.label + '</a>. Отвечаем в течение 7 дней.<br>' +
      '<span style="opacity:.8">Игра сохраняет прогресс и настройки в защищённом хранилище ВКонтакте ' +
      '(VK Storage) и не передаёт их третьим лицам. Мультиплеер использует только ваш ник и результат партии.</span>';
    host.appendChild(box);
  }

  /* ── 4. «Рассказать друзьям» ───────────────────────────────── */
  function addShareButton() {
    var host = document.getElementById('scr-start');
    if (!host || document.getElementById('btn-share-game')) return;
    var card = host.querySelector('.card');
    if (!card) return;
    var btn = document.createElement('button');
    btn.id = 'btn-share-game';
    btn.textContent = '📣 Рассказать друзьям';
    btn.style.cssText = 'margin-top:10px;width:100%;padding:12px 16px;border-radius:14px;cursor:pointer;' +
      'border:1px solid rgba(232,197,106,.40);background:rgba(22,30,56,.85);color:#e9e4d6;font-size:16px;font-weight:600';
    btn.addEventListener('click', function () {
      try {
        if (window.Snd && window.Snd.click) window.Snd.click();
      } catch (e) {}
      if (!isVk) { alert('Кнопка работает внутри ВКонтакте.'); return; }
      bridge.send('VKWebAppShare', { link: 'https://vk.com/app' + (window.__APP_ID || '') })
        .catch(function () {});
    });
    card.appendChild(btn);
  }

  function boot() {
    try { addSupportBlock(); } catch (e) {}
    try { addShareButton(); } catch (e) {}
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { setTimeout(boot, 600); });
  } else {
    setTimeout(boot, 600);
  }
  setTimeout(function () { try { addSupportBlock(); } catch (e) {} }, 3000);
})();
