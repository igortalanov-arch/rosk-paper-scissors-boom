@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo NODE.JS NOT FOUND. Install LTS from https://nodejs.org and run this file again.
  pause
  exit /b 1
)
echo === Step 1: npm install ===
call npm install
if errorlevel 1 (
  echo npm install FAILED. See messages above.
  pause
  exit /b 1
)
echo.
echo === Step 2: deploy to VK hosting ===
set MINI_APPS_ENVIRONMENT=production
call npx vk-miniapps-deploy
echo.
echo Done. Open https://vk.ru/app54845872 with Ctrl+F5.
pause
