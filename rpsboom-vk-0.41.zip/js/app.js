/* ============================================================
 * app.js · v0.36.1 · Обвязка запуска
 * - версия приложения (в заголовке и window.APP_VERSION)
 * - старт VK-платформы, мультиплеера и кнопки хот-сита
 * ============================================================ */
(function () {
  'use strict';
  window.APP_VERSION = window.APP_VERSION || '0.41';

  function setVersion() {
    try {
      var suffix = ' · v' + window.APP_VERSION;
      document.title = (LANG === 'ru'
        ? 'Камень-Ножницы-Бум! Алхимик против Джина'
        : 'Rock-Paper-Boom! Alchemist vs Genie') + suffix;
    } catch (e) {}
    /* плашка версии в подвале стартового экрана */
    try {
      var host = document.getElementById('scr-start');
      if (host && !document.getElementById('ver-badge')) {
        var v = document.createElement('div');
        v.id = 'ver-badge';
        v.textContent = 'v' + window.APP_VERSION + ' · VK Mini Apps · MP · HS';
        v.style.cssText = 'position:absolute;right:10px;bottom:8px;font-size:11px;opacity:.55;letter-spacing:.05em;z-index:5';
        host.appendChild(v);
      }
    } catch (e) {}
  }

  function bootApp() {
    try { setVersion(); } catch (e) {}
    try { if (window.Mp && Mp.boot) Mp.boot(); } catch (e) { console.warn('[boot] Mp', e); }
    try { if (window.HS && HS.installButton) HS.installButton(); } catch (e) { console.warn('[boot] HS', e); }
    /* кнопка хот-сита может пережить пересборку меню — подстраховываемся */
    try {
      if (window.HS && HS.installButton) {
        var re = function () { try { HS.installButton(); } catch (e) {} };
        setTimeout(re, 700); setTimeout(re, 2500);
        window.addEventListener('load', re);
      }
    } catch (e) {}
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { setTimeout(bootApp, 0); });
  } else {
    setTimeout(bootApp, 0);
  }
})();
