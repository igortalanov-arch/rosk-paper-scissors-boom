#!/usr/bin/env python3
"""Единая смена номера версии игры.

Использование:  python3 tools/bump_version.py 0.56 [папка_сборки]

Меняет ВСЕ места, где номер версии виден или используется:
  index.html      <title>, window.APP_VERSION (inline), подвал меню, подвал настроек
  js/app.js       window.APP_VERSION = ... || 'X'
  js/game.js      (window.APP_VERSION||'X')  — заголовок окна и подвал справки
  js/multiplayer.js  window.APP_VERSION || 'X'
  manifest.webmanifest  (если есть поле version)
  package.json    "version"
  README.txt      первая строка «· vX ·»
  VERSION         сам файл-источник

После смены сам печатает отчёт: сколько мест найдено и обновлено.
"""
import json
import os
import re
import sys

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 1
    ver = sys.argv[1].lstrip('v')
    root = sys.argv[2] if len(sys.argv) > 2 else '.'
    total = 0
    report = []

    def patch(path, pattern, repl, flags=0):
        nonlocal total
        full = os.path.join(root, path)
        if not os.path.exists(full):
            return
        src = open(full, encoding='utf-8').read()
        new, n = re.subn(pattern, repl, src, flags=flags)
        if n:
            open(full, 'w', encoding='utf-8').write(new)
            report.append('%-26s %d' % (path, n))
            total += n
        else:
            report.append('%-26s — (не найдено)' % path)

    v = re.escape(ver)
    anyv = r"\d+\.\d+(?:\.\d+)?"

    patch('index.html', r'(<title>[^<]*·\s*v)' + anyv + r'(</title>)', r'\g<1>' + ver + r'\g<2>')
    patch('index.html', r"(window\.APP_VERSION\s*=\s*')" + anyv + r"(')", r'\g<1>' + ver + r'\g<2>')
    patch('index.html', r'(id="best-line"[^>]*>v)' + anyv, r'\g<1>' + ver)
    patch('index.html', r'(id="set-version"[^>]*>v)' + anyv, r'\g<1>' + ver)

    patch('js/app.js', r"(window\.APP_VERSION\s*=\s*window\.APP_VERSION\s*\|\|\s*')" + anyv + r"(')", r'\g<1>' + ver + r'\g<2>')
    patch('js/game.js', r"(window\.APP_VERSION\s*\|\|\s*')" + anyv + r"(')", r'\g<1>' + ver + r'\g<2>')
    patch('js/multiplayer.js', r"(window\.APP_VERSION\s*\|\|\s*')" + anyv + r"(')", r'\g<1>' + ver + r'\g<2>')

    man = os.path.join(root, 'manifest.webmanifest')
    if os.path.exists(man):
        try:
            d = json.load(open(man, encoding='utf-8'))
            if 'version' in d:
                d['version'] = ver
                json.dump(d, open(man, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
                report.append('%-26s 1' % 'manifest.webmanifest')
                total += 1
        except Exception as e:
            report.append('manifest: ошибка %s' % e)

    pkg = os.path.join(root, 'package.json')
    if os.path.exists(pkg):
        try:
            d = json.load(open(pkg, encoding='utf-8'))
            d['version'] = ver if ver.count('.') == 2 else ver + '.0'
            json.dump(d, open(pkg, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
            open(pkg, 'a', encoding='utf-8').write('\n')
            report.append('%-26s 1' % 'package.json')
            total += 1
        except Exception as e:
            report.append('package.json: ошибка %s' % e)

    patch('README.txt', r'^(.*?·\s*v)' + anyv + r'(\s*·)', r'\g<1>' + ver + r'\g<2>', re.M)

    open(os.path.join(root, 'VERSION'), 'w', encoding='utf-8').write(ver + '\n')
    report.append('%-26s %s' % ('VERSION', ver))

    print('Версия: %s' % ver)
    for line in report:
        print('  ' + line)
    print('Всего замен: %d' % total)
    # проверка: не осталось ли других номеров в видимых местах
    return 0

if __name__ == '__main__':
    sys.exit(main())
