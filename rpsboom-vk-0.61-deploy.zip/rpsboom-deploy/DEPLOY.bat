@echo off
cd /d "%~dp0"
set MINI_APPS_ENVIRONMENT=production
call npx --yes @vkontakte/vk-miniapps-deploy@1.0.3
echo.
echo ================ GOTOVO ================
echo Copy the URLs printed above into the three URL fields
echo of the app settings, then press Save.
pause
