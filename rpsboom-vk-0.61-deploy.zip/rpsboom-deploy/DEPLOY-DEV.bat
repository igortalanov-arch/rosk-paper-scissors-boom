@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist node_modules call npm install
set MINI_APPS_ENVIRONMENT=dev
echo Deploying to DEV environment only (no prod URL updates)...
call npx vk-miniapps-deploy
pause
