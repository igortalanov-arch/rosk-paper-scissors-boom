/* ============================================================
 * render-guard.js · v0.36.0 · Загружается ПОСЛЕ game.js
 * Страховка рендера: если WebGL не рисует (нет контекста, потеря
 * контекста, «мёртвый» белый буфер на мобильных GPU, падение
 * RAF-цикла) — рисуем доску и фишки в 2D-подложке поверх канваса.
 * Игра при этом полностью играбельна: тапы считает та же математика.
 * ============================================================ */
(function () {
  'use strict';
  var cv = document.getElementById('gl');
  if (!cv) return;

  var overlay = null, octx = null, overlayOn = false;
  var lastRenderAt = 0, blankStreak = 0, gameWasActive = false;

  function glFailShown() {
    var g = document.getElementById('glfail');
    return !!(g && g.style.display && g.style.display !== 'none');
  }
  function gameActive() {
    try {
      return typeof game !== 'undefined' && game && game.tiles && game.tiles.length > 0 &&
        game.phase !== 'menu' && game.phase !== 'start';
    } catch (e) { return false; }
  }

  /* ---------- 2D-подложка ---------- */
  function ensureOverlay() {
    if (overlay) return overlay;
    overlay = document.createElement('canvas');
    overlay.id = 'gl2d';
    overlay.setAttribute('aria-hidden', 'true');
    overlay.style.cssText = 'position:fixed;display:block;pointer-events:none;z-index:3;';
    document.body.appendChild(overlay);
    octx = overlay.getContext('2d');
    return overlay;
  }
  function syncOverlayRect() {
    var r = cv.getBoundingClientRect();
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    var w = Math.max(1, Math.round(r.width * dpr)), h = Math.max(1, Math.round(r.height * dpr));
    if (overlay.width !== w || overlay.height !== h) { overlay.width = w; overlay.height = h; }
    overlay.style.left = r.left + 'px'; overlay.style.top = r.top + 'px';
    overlay.style.width = r.width + 'px'; overlay.style.height = r.height + 'px';
  }

  var TYPE_COLORS = ['#8fa2c8', '#bcd2f5', '#ff506b', '#f2f5ff', '#c9a24a']; /* 1..4 + запас */
  function tileGlyph(ty) {
    return ty === TOWER ? '🏰' : ty === ROCK ? '🪨' : ty === SCISSORS ? '✂️' : ty === PAPER ? '📄' : '◆';
  }
  function draw2D() {
    ensureOverlay(); syncOverlayRect();
    var ctx = octx, W = overlay.width, H = overlay.height;
    ctx.clearRect(0, 0, W, H);
    try {
      var r = cv.getBoundingClientRect();
      var dpr = W / (r.width || 1);
      /* лунки доски */
      var faces = {}, items = [];
      game.tiles.forEach(function (t) {
        if (!t || t.gone) return;
        faces[t.face] = true;
        var p = project(tilePos(t)), d = 0;
        if (!p) return;
        try { d = tP(mvp(), t.targetPos || tilePos(t))[2]; } catch (e) {}
        items.push({ t: t, x: (p[0] - r.left) * dpr, y: (p[1] - r.top) * dpr, d: d });
      });
      var R = Math.max(16, Math.min(W, H) * 0.052);
      Object.keys(faces).forEach(function (f) {
        f = Number(f);
        for (var row = 0; row < 6; row++) for (var col = 0; col < 6; col++) {
          var p = project(slotGeom1(L1, f, row, col));
          if (!p) continue;
          var x = (p[0] - r.left) * dpr, y = (p[1] - r.top) * dpr;
          ctx.fillStyle = 'rgba(232,197,106,.10)';
          ctx.strokeStyle = 'rgba(232,197,106,.22)';
          ctx.lineWidth = Math.max(1, dpr);
          roundRect(ctx, x - R * 0.92, y - R * 0.92, R * 1.84, R * 1.84, R * 0.28);
          ctx.fill(); ctx.stroke();
        }
      });
      /* фишки: дальние первыми */
      items.sort(function (a, b) { return a.d - b.d; });
      items.forEach(function (it) {
        var t = it.t, mine = t.team === 'player';
        var rad = t.type === TOWER ? R * 1.06 : R * 0.86;
        var g = ctx.createRadialGradient(it.x - rad * 0.3, it.y - rad * 0.4, rad * 0.15, it.x, it.y, rad);
        if (t.type === TOWER) { g.addColorStop(0, mine ? '#5ae29a' : '#ffe9a8'); g.addColorStop(1, mine ? '#1e6b44' : '#8a6a24'); }
        else if (t.color) { g.addColorStop(0, '#dfe5ee'); g.addColorStop(1, '#758097'); }
        else { g.addColorStop(0, TYPE_COLORS[t.type] || '#9aa'); g.addColorStop(1, 'rgba(10,16,34,.9)'); }
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(it.x, it.y, rad, 0, 6.2832); ctx.fill();
        ctx.lineWidth = Math.max(2, dpr * 1.6);
        ctx.strokeStyle = mine ? '#3ddc84' : '#e8c56a';
        ctx.stroke();
        ctx.font = (rad * 1.15) + 'px system-ui,"Segoe UI Emoji",sans-serif';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(tileGlyph(t.type), it.x, it.y + rad * 0.04);
      });
      /* бейдж режима, чтобы было видно, что это страховка */
      if (overlayOn) {
        ctx.font = (11 * dpr) + 'px system-ui,sans-serif';
        ctx.fillStyle = 'rgba(232,197,106,.75)';
        ctx.textAlign = 'left'; ctx.textBaseline = 'top';
        ctx.fillText(LANG === 'ru' ? 'режим совместимости 2D' : '2D compatibility mode', 8 * dpr, 8 * dpr);
      }
    } catch (e) { console.warn('[GL2D]', e); }
  }
  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  function showOverlay() { if (!overlayOn) { ensureOverlay(); overlayOn = true; } draw2D(); }
  function hideOverlay() { overlayOn = false; if (overlay) { octx.clearRect(0, 0, overlay.width, overlay.height); } }

  /* подложка живёт своим RAF, пока включена */
  (function loop2d() {
    if (overlayOn && gameActive()) draw2D();
    requestAnimationFrame(loop2d);
  })();

  /* ---------- детектор «канвас пуст/белый» ---------- */
  function canvasBlank() {
    try {
      var r = cv.getBoundingClientRect();
      if (r.width < 8 || r.height < 8) return true;
      /* снимаем буфер сразу после кадра — иначе без preserveDrawingBuffer он уже очищен */
      try { window.render(); } catch (e) {}
      var tmp = document.createElement('canvas'); tmp.width = 24; tmp.height = 24;
      var c = tmp.getContext('2d');
      c.drawImage(cv, 0, 0, 24, 24);
      var d = c.getImageData(0, 0, 24, 24).data, visible = 0;
      for (var i = 0; i < d.length; i += 4) {
        if (d[i + 3] < 12) continue;
        if (d[i] > 246 && d[i + 1] > 246 && d[i + 2] > 246) continue; /* белый провал */
        visible++;
      }
      return visible < 14;
    } catch (e) { return false; }
  }

  /* перехват render(): считаем живость цикла и гасим исключения */
  var origRender = window.render;
  if (origRender) {
    window.render = function () {
      lastRenderAt = performance.now();
      try { return origRender.apply(this, arguments); }
      catch (e) { console.warn('[GL] render error', e); return; }
    };
  }

  /* потеря/восстановление контекста */
  cv.addEventListener('webglcontextlost', function (e) {
    e.preventDefault();
    lastRenderAt = 0;
    try { showOverlay(); } catch (er) {}
  }, false);
  cv.addEventListener('webglcontextrestored', function () {
    lastRenderAt = performance.now();
    blankStreak = 0;
  }, false);

  /* ---------- watchdog ---------- */
  setInterval(function () {
    var active = gameActive();
    if (active !== gameWasActive) {
      gameWasActive = active;
      if (!active) { hideOverlay(); blankStreak = 0; }
    }
    if (!active) return;
    if (glFailShown()) { showOverlay(); return; }
    var stalled = performance.now() - lastRenderAt > 2500;
    if (stalled) { showOverlay(); return; }
    if (canvasBlank()) blankStreak++; else blankStreak = 0;
    if (blankStreak >= 2) showOverlay();
    else if (blankStreak === 0) hideOverlay();
  }, 1200);

  window.GL_GUARD = { force2d: showOverlay, hide: hideOverlay };
})();
